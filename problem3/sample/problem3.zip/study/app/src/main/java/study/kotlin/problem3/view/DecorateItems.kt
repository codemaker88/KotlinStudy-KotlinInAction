package study.kotlin.problem3.view

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path

/**
 * Created by CodeMaker on 2018-09-10.
 */

//인터페이스 연습
interface Decoratable {

    //인터페이스 추상 프로퍼티
    val paint: Paint

    fun onDraw(canvas: Canvas) {
        //default empty
    }

    override fun toString(): String
}

//클래스 위임 연습
class DefaultDecorate(override val paint: Paint = Paint()) : Decoratable {
    override fun toString(): String {
        return javaClass.simpleName
    }
}

class ColorDecorate(~~~~~~~~~) :  ~~~~~~~~~ {
    ~~~~~~~~~
}

class AlphaDecorate(~~~~~~~~~) : ~~~~~~~~~ {
    ~~~~~~~~~
}

class RectDecorate(~~~~~~~~~) : ~~~~~~~~~ {
    ~~~~~~~~~
}

class CircleDecorate(~~~~~~~~~) : ~~~~~~~~~ {
    ~~~~~~~~~
}

class TriangleDecorate(~~~~~~~~~) : ~~~~~~~~~ {
    ~~~~~~~~~
}

class TextDecorate(~~~~~~~~~) : ~~~~~~~~~{
    ~~~~~~~~~
}

//companion object 연습
class Decorate {
    enum class Shape {
        RECT, CIRCLE, TRIANGLE
    }

    companion object {
        ~~~~~~~~~
    }
}